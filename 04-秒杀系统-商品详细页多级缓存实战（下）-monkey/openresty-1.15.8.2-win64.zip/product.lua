local uri_args = ngx.req.get_uri_args()
local productId = uri_args["productId"]
local cache_ngx = ngx.shared.my_cache
local productCacheKey = "product_info_"..productId
local productCache =cache_ngx:get(productCacheKey)
if productCache == "" or productCache == nil then
     local http = require("resty.http")
	 local httpc = http.new()
	 local resp, err = httpc:request_uri("http://127.0.0.1:8866",{
	 method = "GET",
	 path = "/pms/productInfo/"..productId
	 })
	 productCache = resp.body
	 local expireTime = math.random(600,1200)
	 cache_ngx:set(productCacheKey, productCache, expireTime)
end

local cjson = require("cjson")
local productCacheJSON =cjson.decode(productCache) 
local context = {
	id = productCacheJSON.data.id,
	name = productCacheJSON.data.name,
	price = productCacheJSON.data.price,
	pic = productCacheJSON.data.pic,
	detailHtml = productCacheJSON.data.detailHtml
}

local template = require("resty.template")
template.render("product.html", context)